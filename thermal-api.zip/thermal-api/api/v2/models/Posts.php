<?php
namespace Voce\Thermal\v2\Models;

class Posts {

    public function find( $args = array( ), &$length = null ) {

        //add filter for before/after handling, hopefully more complex date querying
        //will exist by wp3.7
        if ( isset( $args['before'] ) || isset( $args['after'] ) ) {
            add_filter( 'posts_where', array( $this, '_filter_posts_where_handleDateRange' ), 10, 2 );
        }

        // if( isset( $args['post_type'] ) && in_array('attachment', (array) $args['post_type'])) {
        //  if(empty($args['post_status'])) {
        //      $args['post_status'] = array('inherit');
        //  } else {
        //      $args['post_status'] = array_merge((array) $args['post_status'], array('inherit'));
        //  }
        // }

        // if( empty( $args['post_status'] ) ) {
        //  //a post_status is required
        //  return array();
        // }
        $args['post_status'] = 'publish';

        $args['category__not_in'] = array(1486);

        if(empty($args['s'])) {
            unset($args['s']);
        }

        if(isset($args['meta_key']))
        {
            $args['meta_key'] = 'MN_' . $args['meta_key'];

            $now = new \DateTime();

            if(isset($args['list']) && $args['list'] == 'next') {
                $args['meta_query'] = array(
                    array (
                      'key'     => $args['meta_key'],
                      'value'   => $now->format('Y-m-d'),
                      'compare' => '>'
                    )
                );
            }
            else {
                $args['meta_query'] = array(
                    array (
                      'key'     => $args['meta_key'],
                      'value'   => $now->format('Y-m-d'),
                      'compare' => '<='
                    )
                );
            }
        }

        if(isset($args['per_page'])) {
            $args['posts_per_page'] = $args['per_page'];
            unset($args['per_page']);
        }
        $wp_posts = new \WP_Query( $args );

        // var_dump($wp_posts->request);exit;

        // $count_posts = wp_count_posts();
        // $length = $count_posts->publish;

        $args_length = $args;
        unset($args_length['per_page'], $args_length['offset']);
        $wp_all_posts = new \WP_Query( $args_length );
        $length = count($wp_all_posts->posts);

        if(isset($args['s']) && !$length)
        {
            $args['meta_query'] = array(
                'relation' => 'OR',
                array(
                    'key' => 'MN_author',
                    'value' => $args['s'],
                    'compare' => 'LIKE'
                ),
                array(
                    'key' => 'MN_type',
                    'value' => $args['s'],
                    'compare' => 'LIKE'
                ),
                array(
                    'key' => 'MN_editor',
                    'value' => $args['s'],
                    'compare' => 'LIKE'
                ),
            );

            unset($args['s']);

            $wp_posts = new \WP_Query( $args );

            $args_length = $args;
            unset($args_length['per_page'], $args_length['offset']);
            $wp_all_posts = new \WP_Query( $args_length );
            $length = count($wp_all_posts->posts);
        }

        if ( $wp_posts->have_posts() ) {
            return $wp_posts->posts;
        }
        return array();

    }

    public function findById($id) {
        return get_post($id);
    }

    public function _filter_posts_where_handleDateRange( $where, $wp_query ) {
        if ( ($before = $wp_query->get( 'before' ) ) && $beforets = strtotime( $before ) ) {
            if ( preg_match( '$:[0-9]{2}\s[+-][0-9]{2}$', $before ) || strpos( $before, 'GMT' ) !== false ) {
                //adjust to site time if a timezone was set in the timestamp
                $beforets += ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
            }

            $where .= sprintf( " AND post_date < '%s'", gmdate( 'Y-m-d H:i:s', $beforets ) );
        }
        if ( ($after = $wp_query->get( 'after' ) ) && $afterts = strtotime( $after ) ) {
            if ( preg_match( '$:[0-9]{2}\s[+-][0-9]{2}$', $after ) || strpos( $after, 'GMT' ) !== false ) {
                //adjust to site time if a timezone was set in the timestamp
                $afterts += ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
            }

            $where .= sprintf( " AND post_date > '%s'", gmdate( 'Y-m-d H:i:s', $afterts ) );
        }
        remove_filter('posts_search', array($this, __METHOD__));
        return $where;
    }

}
